# -*- coding: utf-8 -*-
"""
Created on Sat Sep 23 13:05:26 2023

@author: Prof. Anderson Oliveira da Silva
"""

import ssl
import socket

# Configuração do contexto SSL no lado do cliente
client_context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)

# Carrega um repositório customizado de certificados confiáveis
client_context.load_verify_locations(cafile="./tls-ca-bundle-custom2.pem")

# Configura o requisito de validação dos certificados recebidos
client_context.verify_mode = ssl.CERT_REQUIRED

# Cria um soquete de rede para usar o contexto SSL
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Estabelece a conexão com o servidor usando o soquete de rede
sock.connect(("localhost", 8443))

# Inicia o handshake TLS com o servidor através do soquete de rede
secure_sock = client_context.wrap_socket(sock, server_hostname="localhost")

# Imprime o resultado da negociação do handshake TLS
print(">>> Resultado da negociação TLS: ", secure_sock.cipher())
print(">>> Algoritmo de compressão negociado: ", secure_sock.compression())

# Envia e recebe dados através do canal de comunicação seguro
print(">>> Enviando requisição protegida para o servidor...")
request = b"GET / HTTP/1.1\r\nHost: localhost\r\n\r\n"
print(request)
secure_sock.sendall(request)
print(">>> Recebendo resposta protegida do servidor...")
response = secure_sock.recv(4096)
print(response)

# Fecha a conexão com o servidor
secure_sock.close()


