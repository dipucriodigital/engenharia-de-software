# -*- coding: utf-8 -*-
"""
Created on Sat Sep 23 13:05:43 2023

@author: Prof. Anderson Oliveira da Silva
"""

import sys
import ssl
import socket

# For server-side connections
server_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)

# Carrega o certificado digital e a chave privada do servidor
server_context.load_cert_chain(certfile="./server-x509-cert.pem", 
                               keyfile="./server-pkcs8-privkey.pem",
                               password=b'serverprivkeypasswd')

# Configura o requisito de validação dos certificados recebidos
server_context.verify_mode = ssl.CERT_NONE

# Cria um soquete de rede para usar o contexto SSL
server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Aloca a porta de comunicação 8443 do localhost para o soquete de rede
print(">>> Alocando a porta de comunicação 8443/TCP...")
server_sock.bind(("localhost", 8443))

# Coloca o soquete de rede no estado listen para aguardar conexões de entrada
print(">>> Entrando no estado listen...aguardando uma conexão...")
server_sock.listen(5)

# Aceita uma conexão de entrada de um cliente
client_sock, client_address = server_sock.accept()

# Inicia o handshake TLS com o cliente através do soquete de rede do cliente
secure_sock_error = False
unexpected_error = False

try:
    secure_sock = server_context.wrap_socket(client_sock, server_side=True)
    print(">>> Handshake TLS realizado com sucesso...")
except ssl.SSLError as err:
    print(">>> Handshake TLS falhou...", err)
    secure_sock_error = True
except Exception as err:
    print(f"Unexpected {err=}, {type(err)=}")
    unexpected_error = True

if secure_sock_error or unexpected_error:
    # Encerra o soquete de rede que está no estado listen
    server_sock.close()
    # Encerra o programa
    sys.exit()
    
# Imprime o resultado da negociação do handshake TLS
print(">>> Resultado da negociação TLS: ", secure_sock.cipher())
print(">>> Algoritmo de compressão negociado: ", secure_sock.compression())

# Recebe e envia dados através do canal de comunicação seguro
print(">>> Recebendo requisição protegida do cliente...")
request = secure_sock.recv(4096)
print(request)
print(">>> Enviando resposta protegida para o cliente...")
response = b"HTTP/1.1 200 OK\r\nContent-Length: 13\r\n\r\nHello, World!"
print(response)
secure_sock.sendall(response)

# Fecha a conexão com o cliente
secure_sock.close()

# Encerra o soquete de rede que está no estado listen
server_sock.close()


