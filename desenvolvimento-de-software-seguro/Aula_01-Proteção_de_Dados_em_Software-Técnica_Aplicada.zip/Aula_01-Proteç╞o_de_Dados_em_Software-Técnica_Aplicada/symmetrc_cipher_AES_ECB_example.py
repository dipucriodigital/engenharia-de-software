# -*- coding: utf-8 -*-
"""
Created on Sun Apr 23 12:11:12 2023

@author: Prof. Anderson Oliveira da Silva
"""

import secrets
from cryptography.hazmat.primitives.ciphers import Cipher,algorithms,modes

keyAES = secrets.token_bytes(32)

cipher = Cipher(
    algorithms.AES(keyAES),
    modes.ECB())

encryptor = cipher.encryptor()

str_plainTextBlock1 = 'Este eh um teste do alg. AES/ECB'
str_plainTextBlock2 = 'Este eh um teste do alg. AES/ECB'

print('str_plainTextBlock1 = "%s" (%i bytes)' % (str_plainTextBlock1, len(str_plainTextBlock1)))
print('str_plainTextBlock2 = "%s" (%i bytes)' % (str_plainTextBlock2, len(str_plainTextBlock2)))

str_plainTextBlocks = str_plainTextBlock1 + str_plainTextBlock2
byte_plainTextBlocks = bytes(str_plainTextBlocks, 'UTF-8')

byte_cipherTextBlocks = encryptor.update(byte_plainTextBlocks) + encryptor.finalize()

byte_cipherTextBlock1 = byte_cipherTextBlocks[:32]
byte_cipherTextBlock2 = byte_cipherTextBlocks[32:]

print('byte_cipherTextBlock1 = "%s" (%i bytes)' % (byte_cipherTextBlock1.hex(), len(byte_cipherTextBlock1)))
print('byte_cipherTextBlock2 = "%s" (%i bytes)' % (byte_cipherTextBlock2.hex(), len(byte_cipherTextBlock2)))

print('Comparando os blocos cifrados calculadas: ', end='')
if (byte_cipherTextBlock1 == byte_cipherTextBlock2):
    print('iguais.')
else:
    print('diferentes.')

decryptor = cipher.decryptor()

byte_newPlainText_Blocks = decryptor.update(byte_cipherTextBlocks) + decryptor.finalize()

byte_newPlainTextBlock1 = byte_newPlainText_Blocks[:32]
byte_newPlainTextBlock2 = byte_newPlainText_Blocks[32:]

str_newPlainTextBlock1 = str(byte_newPlainTextBlock1, 'UTF-8')
str_newPlainTextBlock2 = str(byte_newPlainTextBlock2, 'UTF-8')

print('str_newPlainTextBlock1 = "%s" (%i bytes)' % (str_newPlainTextBlock1, len(str_newPlainTextBlock1)))
print('str_newPlainTextBlock2 = "%s" (%i bytes)' % (str_newPlainTextBlock2, len(str_newPlainTextBlock2)))

