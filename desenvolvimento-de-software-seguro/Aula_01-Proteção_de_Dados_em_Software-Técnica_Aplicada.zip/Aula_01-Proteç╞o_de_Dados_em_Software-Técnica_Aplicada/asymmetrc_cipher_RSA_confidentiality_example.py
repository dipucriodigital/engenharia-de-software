# -*- coding: utf-8 -*-
"""
Created on Sun Apr 23 12:11:12 2023

@author: Prof. Anderson Oliveira da Silva
"""

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding

with open('private_key.pem', 'rb') as private_key_file:
        private_key = serialization.load_pem_private_key(
        private_key_file.read(), 
        b'mypassword')

with open('public_key.pem', 'rb') as public_key_file:
    public_key = serialization.load_pem_public_key(
        public_key_file.read())

str_plainText = "Este eh um teste"
byte_plainText = bytes(str_plainText, 'UTF-8')

print('str_plainText = "%s" (%i bytes)' % (str_plainText, len(str_plainText)))

padding_config = padding.OAEP(
    mgf=padding.MGF1(algorithm=hashes.SHA256()),
    algorithm=hashes.SHA256(),
    label=None)

byte_cipherText = public_key.encrypt(
    plaintext=byte_plainText,
    padding=padding_config)

print('byte_cipherText = "%s" (%i bytes)' % (byte_cipherText.hex(), len(byte_cipherText)))

new_byte_plainText = private_key.decrypt(
    ciphertext=byte_cipherText,
    padding=padding_config)

print('Comparando os bytes do texto plano original com o texto plano decriptado: ', end='')
if (new_byte_plainText == byte_plainText):
    print('iguais.')
else:
    print('diferentes.')

