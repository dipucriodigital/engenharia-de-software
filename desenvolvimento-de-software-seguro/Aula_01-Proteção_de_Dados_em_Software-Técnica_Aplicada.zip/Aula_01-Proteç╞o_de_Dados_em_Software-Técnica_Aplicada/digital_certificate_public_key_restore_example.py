# -*- coding: utf-8 -*-
"""
Created on Sun Apr 23 12:11:12 2023

@author: Prof. Anderson Oliveira da Silva
"""

from cryptography.hazmat.primitives import serialization
from cryptography.x509 import load_pem_x509_certificate
from cryptography.x509 import load_pem_x509_crl
from cryptography.exceptions import InvalidSignature

def print_obj_pem_encoded(obj_pem_encoded_bytes):
    obj_pem_encoded_lines_bytes = obj_pem_encoded_bytes.splitlines()
    print(obj_pem_encoded_lines_bytes[0])
    print(obj_pem_encoded_lines_bytes[1])
    print('...................................................................')
    print(obj_pem_encoded_lines_bytes[-2])
    print(obj_pem_encoded_lines_bytes[-1])

def print_cert_fields(cert_obj):
    print("Versao: ", cert_obj.version)
    print("Serial: ", cert_obj.serial_number)
    print("Valido de: ", cert_obj.not_valid_before)
    print("Valido ate: ", cert_obj.not_valid_after)
    print("Emissor: ", cert_obj.issuer)
    print("Requerente: ", cert_obj.subject)
    print("Alg. Assinatura: ", cert_obj.signature_algorithm_oid)

with open('ac-x509-cert.pem', 'rb') as certificate_file:
    ac_cert_pem_x509_bytes = certificate_file.read()
    
print_obj_pem_encoded(ac_cert_pem_x509_bytes)
ac_cert_obj = load_pem_x509_certificate(ac_cert_pem_x509_bytes)
print_cert_fields(ac_cert_obj)

ac_public_key = ac_cert_obj.public_key()

ac_public_key_pem_bytes = ac_public_key.public_bytes(
   encoding=serialization.Encoding.PEM,
   format=serialization.PublicFormat.SubjectPublicKeyInfo
)

print_obj_pem_encoded(ac_public_key_pem_bytes)

with open('ac-x509-crl.pem', 'rb') as crl_file:
    ac_crl_pem_x509_bytes = crl_file.read()
    
print_obj_pem_encoded(ac_crl_pem_x509_bytes)
ac_crl_obj = load_pem_x509_crl(ac_crl_pem_x509_bytes)

print('>>> Status da LCR da AC: ', end='')
if (ac_crl_obj.is_signature_valid(ac_public_key)):
    print('assinatura válida.')
else:
    print('assinatura inválida')

print('Data de emissão da última LCR: ', ac_crl_obj.last_update)
print('Data de emissão da próxima LCR: ', ac_crl_obj.next_update)
print('>>> Lista de Certificados Revogados (seriais):')
for r in ac_crl_obj:
    print(r.serial_number,', ', end='')
print('Fim da LCR.')

with open('user01-x509-cert.pem', 'rb') as certificate_file:
    user_cert_pem_x509_bytes = certificate_file.read()
    
print_obj_pem_encoded(user_cert_pem_x509_bytes)
user_cert_obj = load_pem_x509_certificate(user_cert_pem_x509_bytes)
print_cert_fields(user_cert_obj)

user_public_key = user_cert_obj.public_key()

user_public_key_pem_bytes = user_public_key.public_bytes(
   encoding=serialization.Encoding.PEM,
   format=serialization.PublicFormat.SubjectPublicKeyInfo
)

print_obj_pem_encoded(user_public_key_pem_bytes)

print('>>> Status do certificado do usuário: ', end='')
try:
    user_cert_obj.verify_directly_issued_by(ac_cert_obj)
    print('assinatura válida, ', end='')
except ValueError:
    print('nome do emissor incorreto ou algoritmo de assinatura não suportada')
    exit(1)
except TypeError:
    print('tipo da chave publica do emissor não suportado')
    exit(1)
except InvalidSignature:
    print('assinatura inválida.')
    exit(1)
    
if (ac_crl_obj.get_revoked_certificate_by_serial_number(user_cert_obj.serial_number) == None):
    print('não revogado.')
else:
    print('revogado.')
    
