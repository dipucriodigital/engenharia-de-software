# -*- coding: utf-8 -*-
"""
Created on Sun Apr 23 12:11:12 2023

@author: Prof. Anderson Oliveira da Silva
"""

from hashlib import sha256

str_plainText1 = 'Este eh um teste!'
str_plainText2 = 'Este eh um teste!'
str_plainText3 = 'Este eh um teste?'

byte_plainText1 = bytes(str_plainText1, 'UTF-8')

hash_obj1 = sha256(byte_plainText1)

hash_obj2 = sha256()
for i in range(0, len(str_plainText2)):
    hash_obj2.update(bytes(str_plainText2[i], 'UTF-8'))

byte_plainText3 = bytes(str_plainText3, 'UTF-8')
hash_obj3 = sha256()
hash_obj3.update(byte_plainText3)

print('Hex_SHA256("'+str_plainText1+'") = '+hash_obj1.hexdigest())
print('Hex_SHA256("'+str_plainText2+'") = '+hash_obj2.hexdigest())
print('Hex_SHA256("'+str_plainText3+'") = '+hash_obj3.hexdigest())

print('Comparando os hashes calculados:')
print('>>> Os dois primeiros hashes calculados são ', end='')
if (hash_obj1.digest() == hash_obj2.digest()):
    print('iguais.')
else:
    print('diferentes.')

print('>>> Os dois ultimos hashes calculados são ', end='')
if (hash_obj2.digest() == hash_obj3.digest()):
    print('iguais.')
else:
    print('diferentes.')
    
print('Tamanho dos hashes calculados com SHA256:')
print('>>> em bytes: ', hash_obj1.digest_size)
print('>>> em bits: ', len(hash_obj2.digest())*8)




