# -*- coding: utf-8 -*-
"""
Created on Sun Apr 23 12:11:12 2023

@author: Prof. Anderson Oliveira da Silva
"""

import secrets
import hashlib
import hmac

key1 = secrets.token_bytes(16)
key2 = key1
key3 = secrets.token_bytes(16)

str_plainText1 = 'Este eh um teste!'
str_plainText2 = 'Este eh um teste!'
str_plainText3 = 'Este eh um teste!'

byte_plainText1 = bytes(str_plainText1, 'UTF-8')
byte_plainText2 = bytes(str_plainText2, 'UTF-8')
byte_plainText3 = bytes(str_plainText3, 'UTF-8')

hmac1_sha256 = hmac.new(key1, msg=byte_plainText1, digestmod=hashlib.sha256)
hmac2_sha256 = hmac.new(key2, msg=byte_plainText2, digestmod=hashlib.sha256)
hmac3_sha256 = hmac.new(key3, msg=byte_plainText3, digestmod=hashlib.sha256)

print('Hex_SHA256("'+str_plainText1+'") = '+hmac1_sha256.hexdigest())
print('Hex_SHA256("'+str_plainText2+'") = '+hmac2_sha256.hexdigest())
print('Hex_SHA256("'+str_plainText3+'") = '+hmac3_sha256.hexdigest())

print('Comparando os hmacs calculados:')
print('>>> Os dois primeiros hmacs calculados são ', end='')
if (hmac1_sha256.digest() == hmac2_sha256.digest()):
    print('iguais.')
else:
    print('diferentes.')

print('>>> Os dois ultimos hmacs calculados são ', end='')
if (hmac2_sha256.digest() == hmac3_sha256.digest()):
    print('iguais.')
else:
    print('diferentes.')
    
print('Tamanho dos hmacs calculados com SHA256:')
print('>>> em bytes: ', hmac1_sha256.digest_size)
print('>>> em bits: ', len(hmac2_sha256.digest())*8)




