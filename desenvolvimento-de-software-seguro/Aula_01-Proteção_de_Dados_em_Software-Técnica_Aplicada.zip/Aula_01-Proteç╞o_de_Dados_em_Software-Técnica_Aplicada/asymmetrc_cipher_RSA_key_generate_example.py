# -*- coding: utf-8 -*-
"""
Created on Sun Apr 23 12:11:12 2023

@author: Prof. Anderson Oliveira da Silva
"""

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

def print_key_pem_encoded(key_pem_encoded_bytes):
    key_pem_encoded_lines_bytes = key_pem_encoded_bytes.splitlines()
    print(key_pem_encoded_lines_bytes[0])
    print(key_pem_encoded_lines_bytes[1])
    print(key_pem_encoded_lines_bytes[2])
    print('...................................................................')
    print(key_pem_encoded_lines_bytes[-2])
    print(key_pem_encoded_lines_bytes[-1])

private_key = rsa.generate_private_key(
    public_exponent=65537,
    key_size=3072,)

public_key = private_key.public_key()

private_key_pem_pkcs8_bytes = private_key.private_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PrivateFormat.PKCS8,
    encryption_algorithm=serialization.NoEncryption())

print_key_pem_encoded(private_key_pem_pkcs8_bytes)

private_key_pem_pkcs8_encrypted_bytes = private_key.private_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PrivateFormat.PKCS8,
    encryption_algorithm=serialization.BestAvailableEncryption(b'mypassword'))

print_key_pem_encoded(private_key_pem_pkcs8_encrypted_bytes)

with open('private_key.pem', 'wb') as private_key_file:
    private_key_file.write(private_key_pem_pkcs8_encrypted_bytes)

public_key_pem_bytes = public_key.public_bytes(
   encoding=serialization.Encoding.PEM,
   format=serialization.PublicFormat.SubjectPublicKeyInfo
)

print_key_pem_encoded(public_key_pem_bytes)

with open('public_key.pem', 'wb') as public_key_file:
    public_key_file.write(public_key_pem_bytes)

