# -*- coding: utf-8 -*-
"""
Created on Sun Apr 23 12:11:12 2023

@author: Prof. Anderson Oliveira da Silva
"""

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.exceptions import InvalidSignature

with open('private_key.pem', 'rb') as private_key_file:
        private_key = serialization.load_pem_private_key(
        private_key_file.read(), 
        b'mypassword')

with open('public_key.pem', 'rb') as public_key_file:
    public_key = serialization.load_pem_public_key(
        public_key_file.read())

str_plainText = "Este eh um teste"
byte_plainText = bytes(str_plainText, 'UTF-8')

print('str_plainText = "%s" (%i bytes)' % (str_plainText, len(str_plainText)))

padding_config = padding.PSS(
    mgf=padding.MGF1(algorithm=hashes.SHA256()),
    salt_length=padding.PSS.MAX_LENGTH)

byte_signature = private_key.sign(
    byte_plainText,
    padding_config,
    hashes.SHA256())

print('byte_signature = "%s" (%i bytes)' % (byte_signature.hex(), len(byte_signature)))

print('Validando a assinatura digital: ', end='')

try:
    public_key.verify(
        byte_signature,
        byte_plainText,
        padding_config,
        hashes.SHA256())
    print('assinatura valida.')
except InvalidSignature:
    print('assinatura invalida.')

