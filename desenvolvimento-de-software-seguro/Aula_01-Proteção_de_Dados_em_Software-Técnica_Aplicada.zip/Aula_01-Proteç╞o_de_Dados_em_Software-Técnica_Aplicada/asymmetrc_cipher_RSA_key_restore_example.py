# -*- coding: utf-8 -*-
"""
Created on Sun Apr 23 12:11:12 2023

@author: Prof. Anderson Oliveira da Silva
"""

from cryptography.hazmat.primitives import serialization

def print_key_pem_encoded(key_pem_encoded_bytes):
    key_pem_encoded_lines_bytes = key_pem_encoded_bytes.splitlines()
    print(key_pem_encoded_lines_bytes[0])
    print(key_pem_encoded_lines_bytes[1])
    print(key_pem_encoded_lines_bytes[2])
    print('...................................................................')
    print(key_pem_encoded_lines_bytes[-2])
    print(key_pem_encoded_lines_bytes[-1])

with open('private_key.pem', 'rb') as private_key_file:
        private_key = serialization.load_pem_private_key(
        private_key_file.read(), 
        b'mypassword')
        
private_key_pem_pkcs8_bytes = private_key.private_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PrivateFormat.PKCS8,
    encryption_algorithm=serialization.NoEncryption())

print_key_pem_encoded(private_key_pem_pkcs8_bytes)

with open('public_key.pem', 'rb') as public_key_file:
    public_key = serialization.load_pem_public_key(
        public_key_file.read())

public_key_pem_bytes = public_key.public_bytes(
   encoding=serialization.Encoding.PEM,
   format=serialization.PublicFormat.SubjectPublicKeyInfo
)

print_key_pem_encoded(public_key_pem_bytes)

